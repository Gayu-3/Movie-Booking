export const environment = {
  production: false,
  apiBaseUrl: 'https://localhost:7213/api'
};
