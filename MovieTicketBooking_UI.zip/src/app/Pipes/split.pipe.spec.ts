import { SplitPipe } from './split.pipe';

describe('SplitPipe', () => {
  it('create an instance', () => {
    const pipe = new SplitPipe();
    expect(pipe).toBeTruthy();
  });
});
