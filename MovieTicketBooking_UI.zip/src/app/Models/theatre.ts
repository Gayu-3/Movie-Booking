export interface Theatre {
    id: string;
    theatreName: string;
    city: string;
    availableSeat: number;
    created: Date;
    updated: Date;
}
